package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etName, ettPassword;
    private Button btnSend;
    private TextView tvReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        ettPassword = findViewById(R.id.ettPassword);
        btnSend = findViewById(R.id.btnSend);
        tvReset = findViewById(R.id.tvReset);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void validateInputs() {
        String user = etName.getText().toString().trim();
        String password = ettPassword.getText().toString().trim();

        if (TextUtils.isEmpty(user)) {
            etName.setError("Ingrese su usuario");
            etName.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            ettPassword.setError("Ingrese su contraseña");
            ettPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            ettPassword.setError("La contraseña debe tener al menos 6 caracteres");
            ettPassword.requestFocus();
            return;
        }

        Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
    }
}